
My fonts for free use are allowed only in personal projects, and non-profit.
If you make money/ use for commercial   using my fonts, Please purchase a commercial license.

NOTE :

By installing or using this font, you are agree to the Product Usage Agreement:

- This font is already FULL VERSION and ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- Here is the link to purchase commercial license: 
https://skiillerstudio.com/

- For Corporate use you have to purchase Corporate license


Please visit our store for more amazing fonts : 
https://skiillerstudio.com/

-----------------------------------------------

Thank you :)



CAUTION!
Anyone who uses personal use fonts for commercial needs without buying a commercial license and without permission from the author, will be subject to fines.


----------------------------------------------
----------------------------

Silakan gunakan lisensi komersial dengan membeli melalui link ini : 
https://skiillerstudio.com/

menggunakan font ini untuk komersil tanpa membeli lisensinya dulu akan dikenakan 
biaya pelanggaran sebesar Rp 50.000.000 (lima puluh lima juta rupiah).

Terima Kasih...


